import javax.swing.*;

public class VendingMachine { 
	public static void main(String args[]) {
		BuildMachine(); 
		//mengaktifkan JFrame dan ditampilkan di layar
		// bersambung dengan VendingMachineUI.class
	} // END main(String args[])

	public static void BuildMachine() {
		// membuat objek baru VendingMachine yang merupakan objek JFrame
		JFrame VendingMachine = new VendingMachineUI();
		// membuat objek JFrame
		VendingMachine.show(); 
	} // END BuildMachine()

} // END VendingMachine